#  CMP1903 O-O-P Assessment 1 Report:
## I have reviewed the code produced by Samuel Jonathan Orman-Chan (ID: 25659005) and Luke-A-C-Roberts (ID: 25722923)

Samual Jonathan Orman-Chan : https://github.com/SJO-C/CMP1903M/issues/8
Luke-A-C-Roberts : https://github.com/Luke-A-C-Roberts/CMP1903M-Assessment-1-Repository/issues/4

## My code was reviewed by LukasSob (ID: 25728866), Nathan Edwards (ID: 25725278), Samuel Jonathan Orman-Chan (ID: 25659005) and Stevie Goodman (ID: 25175912)

The most frequent comments when it came to my code where about my unsimplified Regex Filters and 
lack of commenting. I took onboard all the comments in these reviews and tweaked my code to reflect this.
Other features I implemented due to review was displaying the retrieved text from the used textfile, 
allow program rerun and closing as choices and moving a bit of program.cs into input.cs to improve abstraction.
